#!/bin/bash
# Start Attacker Infrastructure (C2 + PyPI Server)

set -e

echo "=========================================="
echo "  Starting Attacker Infrastructure"
echo "=========================================="
echo ""

# Get script directory
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Create packages directory if it doesn't exist
mkdir -p packages/simple

echo "[*] Installing dependencies..."
pip install -q -r requirements.txt

echo "[*] Starting C2 server with integrated PyPI server..."
echo "[*] Press Ctrl+C to stop"
echo ""

# Run the C2 server
python3 c2_server.py
